from itertools import izip
from PIL import Image
import sys
import re
import os
import datetime

# Compares images bit by bit. Calculates the percent difference and outputs it to the terminal.
# Only compares the first two images with the same ID.
def main(args):
	folder_to_load = "" # <<< Hard coded input dir 
	folderLoad(folder_to_load)


def folderLoad(folder_to_load):
	files = os.listdir(folder_to_load+"/")

	output = [] # List of all cameras in all files

	fileList = []
	for onefile in files:
		if onefile.find(".png") != -1:
			fileList.append(onefile)

	x = 0
	while x < len(fileList):
		ID = re.search(r'(?P<ID>[^_]*)_(?P<datetime>[^\.]*)', fileList[x]).group("ID")
		idGroup = [fileList[x]]
		while x + 1 < len(fileList) and ID == re.search(r'(?P<ID>[^_]*)_(?P<datetime>[^\.]*)', fileList[x+1]).group("ID"):
			x = x + 1
			idGroup.append(fileList[x])
		
		x = x + 1

		dateList = []
		for img in idGroup:
			date = re.search(r'(?P<ID>[^_]*)_(?P<datetime>[^\.]*)', img).group("datetime")
			date = datetime.datetime.strptime(date, "%Y-%m-%d_%H-%M-%S-%f")
			dateList.append(date)

		if len(dateList) > 1:
			dateDiff = dateList[1]-dateList[0]

		if len(idGroup) > 1:
			try:
				diff = compareImages(folder_to_load+"/"+idGroup[0], folder_to_load+"/"+idGroup[1])
				print "{},{},{}".format(ID, dateDiff, diff)	
				
			except Exception, e:
				print e


def compareImages(img1, img2):
	i1 = Image.open(img1)
	i2 = Image.open(img2)
	assert i1.mode == i2.mode, "Different kinds of images. {}{}".format(img1,img2)
	assert i1.size == i2.size, "Different sizes. {}{}".format(img1,img2)
	 
	pairs = izip(i1.getdata(), i2.getdata())
	if len(i1.getbands()) == 1:
		# for gray-scale jpegs
		dif = sum(abs(p1-p2) for p1,p2 in pairs)
	else:
		dif = sum(abs(c1-c2) for p1,p2 in pairs for c1,c2 in zip(p1,p2))
	 
	ncomponents = i1.size[0] * i1.size[1] * 3

	difference = (dif / 255.0 * 100) / ncomponents
	# print "Difference (percentage) between {} and {} is {}%".format(img1, img2, difference)	
	return difference
	
if __name__ == '__main__':
	main(sys.argv)