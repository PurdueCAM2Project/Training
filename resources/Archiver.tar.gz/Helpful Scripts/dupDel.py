from __future__ import print_function
import os
import re
import filecmp
import sys

# Deletes duplicate images biased on id from the archiver or using the filecomp module
def delDups(results_path):
	currdir = os.getcwd()
	os.chdir(currdir+"/"+results_path)
	files = os.listdir(os.curdir)
	diffFiles = []

	for onefile in files:
		if onefile.find(".png") != -1:
			diffFiles.append(onefile)
	
	removeIDs = []
	for pic1 in diffFiles:
		ID1 = re.search(r'(?P<ID>[\d]*)', pic1).group("ID")
		for pic2 in diffFiles:
			ID2 = re.search(r'(?P<ID>[\d]*)', pic2).group("ID")
			try:
				# if filecmp.cmp(pic1, pic2) == True and pic1 != pic2:  # <<<Uncomment if you want to delete using filecmp module
				if ID1 == ID2 and pic1 != pic2:
					# print(ID1,ID2)
					# print(pic1,pic2)
					if ID1 not in removeIDs:
						removeIDs.append(ID1)
						os.remove(pic2)
						break
			except Exception as e:
				print(e)
				pass

if __name__ == '__main__':
	results_path ="" # <<< Results path hard coded 
	delDups(results_path)